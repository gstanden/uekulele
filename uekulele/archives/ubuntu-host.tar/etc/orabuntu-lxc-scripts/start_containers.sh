#!/bin/bash

function GetContainersStopped {
sudo lxc-ls -f | grep STOPPED | sed 's/  */ /g' | cut -f1 -d' ' | sed 's/$/ /' | tr -d '\n'
}
ContainersStopped=$(GetContainersStopped)

for i in $ContainersStopped
do
sudo lxc-start -n $i
done
