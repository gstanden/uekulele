#!/bin/bash
# Requires use of Upstart Script /etc/init/my-network-up.conf to ensure interfaces are up before running.
sleep 2
ip tuntap add s1 mode tap 
ip tuntap add s2 mode tap 
ip tuntap add s3 mode tap 
# ip tuntap add s4 mode tap 
# ip tuntap add s5 mode tap 
ip link set s1 up
ip link set s2 up
ip link set s3 up
# ip link set s4 up
# ip link set s5 up
ovs-vsctl add-br sw1
ovs-vsctl add-port sw1 s1
ovs-vsctl add-port sw1 s2
ovs-vsctl add-port sw1 s3
# ovs-vsctl add-port sw1 s4
# ovs-vsctl add-port sw1 s5

ip link set up dev sw1
ip addr add 10.207.39.1/24 dev sw1
ip route replace 10.207.39.0/24 dev sw1

ovs-vsctl set port sw1 trunks=10
ovs-vsctl set port sw1 tag=10
ovs-vsctl set port s1 tag=10
ovs-vsctl set port s2 tag=10
ovs-vsctl set port s3 tag=10
# ovs-vsctl set port s4 tag=10
# ovs-vsctl set port s5 tag=10

# GLS 20140825 Get active external interface dynamically at boot.  Tested & works with {wlan0, eth0, bnep0} on Ubuntu 14.04.1 Desktop x86_64.
# GLS 20140825 Interface "bnep0" is Blackberry Z30 OS10 Bluetooth Tether.

### BEGIN Get Active EXTIF Dynamcially. ###
function GetInterface
{
ifconfig | egrep -B1 'inet' | egrep -A1 'enp|wlp|wlan|eth|bnep' | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f1,7 -d' ' | sed 's/ addr//' | head -1 | cut -f1 -d':'
}
Interface=$(GetInterface)
function GetIP
{
ifconfig | grep -A1 $Interface | grep inet | sed '$!N;s/\n/ /' | sed 's/  */ /g' | cut -f3 -d' '
}
### END Get Active EXTIF Dynamically. ###

echo '       IP: '$(GetIP)
echo 'Interface: '$(GetInterface)

INTIF="sw1"
EXTIF=$(GetInterface)

echo 1 > /proc/sys/net/ipv4/ip_forward

# clear existing iptable rules, set a default policy
iptables -P INPUT ACCEPT
iptables -F INPUT 
iptables -P OUTPUT ACCEPT
iptables -F OUTPUT 
iptables -P FORWARD DROP
iptables -F FORWARD 
iptables -t nat -F

function CheckIptablesRulesCount {
iptables -S | grep FORWARD | grep sw1 | wc -l
}
IptablesRulesCount=$(CheckIptablesRulesCount)
while [ $IptablesRulesCount -ne 0 ]
do
iptables -D FORWARD -i $EXTIF -o $INTIF -j ACCEPT > /dev/null 2>&1
iptables -D FORWARD -i $INTIF -o $EXTIF -j ACCEPT > /dev/null 2>&1
IptablesRulesCount=$(CheckIptablesRulesCount)
done

# set forwarding and nat rules
iptables -A FORWARD -i $EXTIF -o $INTIF -j ACCEPT
iptables -A FORWARD -i $INTIF -o $EXTIF -j ACCEPT
iptables -t nat -A POSTROUTING -o $EXTIF -j MASQUERADE

service dhcpd start
service named restart

