groupadd -g 1001 oinstall
groupadd -g 1100 asmadmin
groupadd -g 1200 dba
groupadd -g 1300 asmdba
groupadd -g 1201 oper
groupadd -g 1301 asmoper

# new additions 12c
groupadd -g 1401 backupdba
groupadd -g 1501 dgdba
groupadd -g 1601 kmdba
groupadd -g 1701 osacfs
groupadd -g 1801 osaudit
usermod -a -G backupdba,dgdba,kmdba oracle
# end new additions 12c

useradd -u 1098 -g oinstall -G asmadmin,asmdba,asmoper,dba grid
usermod -a -G dba,asmdba,oper,oinstall oracle
mkdir -p /u00/app/12.1.0/grid
mkdir -p /u00/app/grid
chown -R grid:oinstall /u00
mkdir -p /u00/app/oracle
chown oracle:oinstall /u00/app/oracle
chmod -R 775 /u00
