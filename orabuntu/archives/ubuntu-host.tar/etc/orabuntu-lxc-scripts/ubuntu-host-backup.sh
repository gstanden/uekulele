#!/bin/bash

export DATEXT=`date +'%y%m%d_%H%M%S'`

if [ -e /etc/resolv.conf ] && [ ! -e /etc/resolv.conf.orabuntu-lxc.original.* ]
then
sudo cp -p /etc/resolv.conf /etc/resolv.conf.orabuntu-lxc.original.$DATEXT
sudo ls -l /etc/resolv.conf /etc/resolv.conf.orabuntu-lxc.original.$DATEXT
fi

if [ -e /etc/multipath.conf ] && [ ! -e /etc/multipath.conf.orabuntu-lxc.original.* ]
then
sudo cp -p /etc/multipath.conf /etc/multipath.conf.orabuntu-lxc.original.$DATEXT
sudo ls -l /etc/multipath.conf /etc/multipath.conf.orabuntu-lxc.original.$DATEXT
fi

if [ -e /etc/sysctl.d/60-oracle.conf ] && [ ! -e /etc/sysctl.d/60-oracle.conf.orabuntu-lxc.original.* ]
then
sudo cp -p /etc/sysctl.d/60-oracle.conf /etc/sysctl.d/60-oracle.conf.orabuntu-lxc.original.$DATEXT
sudo ls -l /etc/sysctl.d/60-oracle.conf /etc/sysctl.d/60-oracle.conf.orabuntu-lxc.original.$DATEXT
fi

if [ -e /etc/security/limits.d/60-oracle.conf ] && [ ! -e /etc/security/limits.d/60-oracle.conf.orabuntu-lxc.original.* ]
then
sudo cp -p /etc/security/limits.d/60-oracle.conf /etc/security/limits.d/60-oracle.conf.orabuntu-lxc.original.$DATEXT
sudo ls -l /etc/security/limits.d/60-oracle.conf /etc/security/limits.d/60-oracle.conf.orabuntu-lxc.original.$DATEXT
fi

if [ -e /etc/NetworkManager/dnsmasq.d/local ] && [ ! -e /etc/NetworkManager/dnsmasq.d/local.orabuntu-lxc.original.* ]
then
sudo cp -p /etc/NetworkManager/dnsmasq.d/local /etc/NetworkManager/dnsmasq.d/local.orabuntu-lxc.original.$DATEXT
sudo ls -l /etc/NetworkManager/dnsmasq.d/local /etc/NetworkManager/dnsmasq.d/local.orabuntu-lxc.original.$DATEXT
fi

